'''
Created on 26 Jan 2015

@author: chriseisbrown
'''
class EuroPMCArticle(object):
    def __init__(self):
        self.id = ""
        self.source = ""
        self.pmid = ""
        self.disease_name = ""
        self.title = ""
        self.pub_year = ""
        self.author_string = ""



