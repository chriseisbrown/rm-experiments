'''
Created on 04 Feb 2015

@author: chriseisbrown
'''
class Disease(object):
    def __init__(self):
        self._id = ""
        self.name = ""
        self.short_name = ""
        self.mesh_category = []

